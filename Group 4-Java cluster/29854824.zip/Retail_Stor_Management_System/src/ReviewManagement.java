import java.sql.*;
import java.io.BufferedReader;
import java.io.IOException;

public class ReviewManagement 
{

    public void addReview(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter product ID: ");
            int productId = Integer.parseInt(reader.readLine());

            System.out.print("Enter customer ID: ");
            int customerId = Integer.parseInt(reader.readLine());

            System.out.print("Enter rating (1-5): ");
            int rating = Integer.parseInt(reader.readLine());

            System.out.print("Enter comment: ");
            String comment = reader.readLine();

            String sql = "INSERT INTO Review (product_id, customer_id, rating, comment, review_date) VALUES (?, ?, ?, ?, NOW())";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            pstmt.setInt(2, customerId);
            pstmt.setInt(3, rating);
            pstmt.setString(4, comment);
            pstmt.executeUpdate();

            System.out.println("Review added successfully!");

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error adding review: " + e.getMessage());
        }
    }

    public void viewReviews(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection())
        {
            System.out.print("Enter product ID to view reviews: ");
            int productId = Integer.parseInt(reader.readLine());

            String sql = "SELECT * FROM Review WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) 
            {
                System.out.println("Review ID: " + rs.getInt("review_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Rating: " + rs.getInt("rating"));
                System.out.println("Comment: " + rs.getString("comment"));
                System.out.println("Review Date: " + rs.getDate("review_date"));
                System.out.println("-------------------------");
            }

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error viewing reviews: " + e.getMessage());
        }
    }

    public void deleteReview(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter review ID to delete: ");
            int reviewId = Integer.parseInt(reader.readLine());

            String sql = "DELETE FROM Review WHERE review_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, reviewId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) 
            {
                System.out.println("Review deleted successfully!");
            } 
            else 
            {
                System.out.println("Review not found.");
            }

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error deleting review: " + e.getMessage());
        }
    }
}
