import java.sql.*;
import java.io.BufferedReader;
import java.io.IOException;

public class CustomerManagement 
{

    public void addCustomer(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter customer name: ");
            String name = reader.readLine();

            System.out.print("Enter customer email: ");
            String email = reader.readLine();

            System.out.print("Enter customer phone number: ");
            String phoneNumber = reader.readLine();

            System.out.print("Enter customer address: ");
            String address = reader.readLine();

            String sql = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, address);
            pstmt.executeUpdate();

            System.out.println("Customer added successfully!");

        } 
        catch (SQLException | IOException e) 
        {
            System.out.println("Error adding customer: " + e.getMessage());
        }
    }

    public void viewCustomerDetails(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter customer ID: ");
            int customerId = Integer.parseInt(reader.readLine());

            String sql = "SELECT * FROM Customer WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) 
            {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("Address: " + rs.getString("address"));
            } 
            else 
            {
                System.out.println("Customer not found.");
            }

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error viewing customer details: " + e.getMessage());
        }
    }

    public void updateCustomer(BufferedReader reader)
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter customer ID to update: ");
            int customerId = Integer.parseInt(reader.readLine());

            System.out.print("Enter new customer name: ");
            String name = reader.readLine();

            System.out.print("Enter new customer email: ");
            String email = reader.readLine();

            System.out.print("Enter new customer phone number: ");
            String phoneNumber = reader.readLine();

            System.out.print("Enter new customer address: ");
            String address = reader.readLine();

            String sql = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, address);
            pstmt.setInt(5, customerId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) 
            {
                System.out.println("Customer updated successfully!");
            } 
            else 
            {
                System.out.println("Customer not found.");
            }

        } 
        catch (SQLException | IOException e) 
        {
            System.out.println("Error updating customer: " + e.getMessage());
        }
    }

    public void deleteCustomer(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter customer ID to delete: ");
            int customerId = Integer.parseInt(reader.readLine());

            String sql = "DELETE FROM Customer WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, customerId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) 
            {
                System.out.println("Customer deleted successfully!");
            } 
            else 
            {
                System.out.println("Customer not found.");
            }

        } 
        catch (SQLException | IOException e)
        {
            System.out.println("Error deleting customer: " + e.getMessage());
        }
    }
}
