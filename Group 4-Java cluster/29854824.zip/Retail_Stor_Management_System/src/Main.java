import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
//public class that combines all the other classes
public class Main 
{
    public static void main(String[] args) 
    {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        ProductManagement productManagement = new ProductManagement();
        CustomerManagement customerManagement = new CustomerManagement();
        ReviewManagement reviewManagement = new ReviewManagement();
        //A loop to check for the possible options in main menu
        while (true) 
        {
            try 
            {
                System.out.println("Online Retail Store Management System");
                System.out.println("1. Product Management");
                System.out.println("2. Customer Management");
                System.out.println("3. Review Management");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = Integer.parseInt(reader.readLine());

                switch (choice) 
                {
                //choice 1 leads to the Project Management Method
                    case 1:
                        productManagementMenu(reader, productManagement);
                        break;
                //choice 2 leads to the Customer Management Method
                    case 2:
                        customerManagementMenu(reader, customerManagement);
                        break;
                //choice 3 leads to the Review Management Method
                    case 3:
                        reviewManagementMenu(reader, reviewManagement);
                        break;
                //choice 4 leads to the Exit
                    case 4:
                        System.out.println("Exiting...");
                        return;
                //default it is invalid choice for numbers not in the list
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } 
            catch (IOException | NumberFormatException e) 
            {
                System.out.println("Invalid input. Please try again.");
            }
        }
    }
    //Methods to call the Methods in ProductManagement class as per requirement 
    private static void productManagementMenu(BufferedReader reader, ProductManagement productManagement) {
        try 
        {
            System.out.println("Product Management");
            System.out.println("1. Add Product");
            System.out.println("2. View Product Details");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = Integer.parseInt(reader.readLine());

            switch (choice) 
            {
                case 1:
                    productManagement.addProduct(reader);
                    break;
                case 2:
                    productManagement.viewProductDetails(reader);
                    break;
                case 3:
                    productManagement.updateProduct(reader);
                    break;
                case 4:
                    productManagement.deleteProduct(reader);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } 
        catch (IOException | NumberFormatException e) 
        {
            System.out.println("Invalid input. Please try again.");
        }
    }
    //Method to call the Methods in ProductManagement class as per requirement 
    private static void customerManagementMenu(BufferedReader reader, CustomerManagement customerManagement) {
        try {
            System.out.println("Customer Management");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = Integer.parseInt(reader.readLine());

            switch (choice) 
            {
                case 1:
                    customerManagement.addCustomer(reader);
                    break;
                case 2:
                    customerManagement.viewCustomerDetails(reader);
                    break;
                case 3:
                    customerManagement.updateCustomer(reader);
                    break;
                case 4:
                    customerManagement.deleteCustomer(reader);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } 
        catch (IOException | NumberFormatException e) 
        {
            System.out.println("Invalid input. Please try again.");
        }
    }
    //function to call the functions in ProductManagement class as per requirement
    private static void reviewManagementMenu(BufferedReader reader, ReviewManagement reviewManagement) 
    {
        try 
        {
            System.out.println("Review Management");
            System.out.println("1. Add Review");
            System.out.println("2. View Reviews");
            System.out.println("3. Delete Review");
            System.out.println("4. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = Integer.parseInt(reader.readLine());

            switch (choice) 
            {
                case 1:
                    reviewManagement.addReview(reader);
                    break;
                case 2:
                    reviewManagement.viewReviews(reader);
                    break;
                case 3:
                    reviewManagement.deleteReview(reader);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } 
        catch (IOException | NumberFormatException e) 
        {
            System.out.println("Invalid input. Please try again.");
        }
    }
}
