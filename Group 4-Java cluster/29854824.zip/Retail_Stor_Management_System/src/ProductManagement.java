import java.sql.*;
import java.io.BufferedReader;
import java.io.IOException;

public class ProductManagement 
{

    public void addProduct(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter product name: ");
            String name = reader.readLine();

            System.out.print("Enter product description: ");
            String description = reader.readLine();

            System.out.print("Enter product price: ");
            double price = Double.parseDouble(reader.readLine());

            System.out.print("Enter stock quantity: ");
            int stockQuantity = Integer.parseInt(reader.readLine());

            String sql = "INSERT INTO Product (name, description, price, stock_quantity) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, stockQuantity);
            pstmt.executeUpdate();

            System.out.println("Product added successfully!");

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }

    public void viewProductDetails(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter product ID: ");
            int productId = Integer.parseInt(reader.readLine());

            String sql = "SELECT * FROM Product WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) 
            {
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Stock Quantity: " + rs.getInt("stock_quantity"));
            } 
            else 
            {
                System.out.println("Product not found.");
            }

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error viewing product details: " + e.getMessage());
        }
    }

    public void updateProduct(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter product ID to update: ");
            int productId = Integer.parseInt(reader.readLine());

            System.out.print("Enter new product name: ");
            String name = reader.readLine();

            System.out.print("Enter new product description: ");
            String description = reader.readLine();

            System.out.print("Enter new product price: ");
            double price = Double.parseDouble(reader.readLine());

            System.out.print("Enter new stock quantity: ");
            int stockQuantity = Integer.parseInt(reader.readLine());

            String sql = "UPDATE Product SET name = ?, description = ?, price = ?, stock_quantity = ? WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, stockQuantity);
            pstmt.setInt(5, productId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) 
            {
                System.out.println("Product updated successfully!");
            } 
            else 
            {
                System.out.println("Product not found.");
            }

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error updating product: " + e.getMessage());
        }
    }

    public void deleteProduct(BufferedReader reader) 
    {
        try (Connection conn = DatabaseConnection.getConnection()) 
        {
            System.out.print("Enter product ID to delete: ");
            int productId = Integer.parseInt(reader.readLine());

            String sql = "DELETE FROM Product WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) 
            {
                System.out.println("Product deleted successfully!");
            } 
            else 
            {
                System.out.println("Product not found.");
            }

        } 
        catch (SQLException | IOException | NumberFormatException e) 
        {
            System.out.println("Error deleting product: " + e.getMessage());
        }
    }
}
